<?php

class Login extends Controller {

    function __construct() {
        parent::__construct();
        //echo Hash::create('sha256', 'pass2018LM*', HASH_PASSWORD_KEY);
        //echo $this->helper->encrypt('*I^bz{xApIh?gg++', 'e');
    }

    public function index() {
        #cargamos la vista
        $this->view->title = 'Inicie Sesión';
        $this->view->render('admin/login/header');
        $this->view->render('admin/login/index');
        $this->view->render('admin/login/footer');
        if (isset($_SESSION['message']))
            unset($_SESSION['message']);
    }

    public function iniciar() {
        $datos = array(
            'email' => $this->helper->cleanInput($_POST['login']['email']),
            'contrasena' => $this->helper->cleanInput($_POST['login']['contrasena']),
        );
        $data = $this->model->iniciar($this->idioma, $datos);
        echo json_encode($data);
    }

    public function salir() {
        session_destroy();
        Auth::handleLogin();
    }

}
