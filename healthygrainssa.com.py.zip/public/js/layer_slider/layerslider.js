		jQuery("#layerslider").layerSlider({
			responsive: false,
			responsiveUnder: 1170,
			layersContainer: 1170,
			skin: 'fullwidth',
			hoverPrevNext: true,
			skinsPath: 'css/layerslider/skins/'
		});

		jQuery("#layersliderFS").layerSlider({
			responsive: false,
			skin: 'fullwidth',
			hoverPrevNext: true,
			skinsPath: 'css/layerslider/skins/'
		});